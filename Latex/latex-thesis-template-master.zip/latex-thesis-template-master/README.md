These templates are used for writing and defending thesis
