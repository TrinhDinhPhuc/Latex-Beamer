# LatexBasics

[Full Youtube playlist](https://www.youtube.com/watch?v=Qc82mJTDzt8&index=2&list=PLlsF2nDmyL7msihnebzII_KVWy6URxDfp)


## 1. Brief Introduction 

## 2. Installing LaTeX 

## 3. Online Editors - CV/Resume

## 4. To be determined
