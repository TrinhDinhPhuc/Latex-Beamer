# beamer-samples
Slides which are prepared based on beamer


These examples are for references.

PS: I do not hold any lisences for the files.
please see the individual files (I haven't edited any files)
for the specific lisences.

Have a good learning of beamer and latex.
